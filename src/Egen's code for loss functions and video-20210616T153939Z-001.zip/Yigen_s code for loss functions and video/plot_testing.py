# Author: Yigen
# This file is used to draw the IoU accuracy of different loss functions

import matplotlib.pyplot as plt
import numpy as np

x_L1 = np.array([2000,	4000,	6000,	8000,	10000,	20000,	40000,	60000])
x_SmoothL1 = np.array([2000,	4000,	6000,	8000,	10000,	20000,	40000,	60000])
x_IoU = np.array([5000,	10000,	20000,	30000,	40000,	50000,	60000,	70000,	80000,	85000])
x_GIoU = np.array([5000,	10000,	15000,	20000, 30000, 40000, 50000, 60000])
x_DIoU = np.array([2000,	4000,	6000,	8000,	10000, 20000, 30000, 40000, 50000, 60000])
x_CIoU = np.array([2000,	4000,	6000,	8000,	10000])

y_L1_a_Boy = [0.2501848359,	0.09721162969,	0.288820963,	0.1601135951,	0.03242102616,	0.7506019397,	0.6212243,	0.5493742548]
y_SmoothL1_a_Boy = [0.03153707616,	0.02655007523,	0.03951906679,	0.0258118494,	0.07003288524,	0.6982978574,	0.2643010148,	0.3729100682]
y_IoU_a_Boy = [0.1466112401,	0.2640405187,	0.4884742423,	0.4990291436,	0.4021934571,	0.4110483445,	0.4198672843,	0.4084107421,	0.4084072982,	0.4084072986]
y_GIoU_a_Boy = [0.3313977046,	0.3972763777,	0.4422327132,	0.3765709122,	0.3950287201,	0.4114832231,	0.390526994,	0.3882027827]
y_DIoU_a_Boy = [0.08852821033,	0.06474159818,	0.4163290812,	0.08649438753,	0.1101623898, 0.4090936498,	0.4290624721,	0.3917872022,	0.3877811574,	0.4041932119]
y_CIoU_a_Boy = [0.0166324845,	0.2204309349,	0.1499119779,	0.4877487888,	0.1193924309]


plt.figure()
plt.plot(x_L1, y_L1_a_Boy, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Boy, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Boy, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Boy, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Boy, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Boy, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Boy')



y_L1_a_Car2 = [0.173487086,	0.05315454943,	0.1101032705,	0.3866337645,	0.02867897325,	0.03771050082,	0.1925269329,	0.2146030298]
y_SmoothL1_a_Car2 = [0.09593126668,	0.03111284408,	0.07170928312,	0.08010210043,	0.1058617257,	0.01272240457,	0.4268732203,	0.4058671296]
y_IoU_a_Car2 = [0.1166501906,	0.3215655499,	0.4768873804,	0.4845506732,	0.4927681671,	0.4992285367,	0.4944557215,	0.4425250253,	0.4425224476,	0.4425224173]
y_GIoU_a_Car2 = [0.384959068,	0.5325684353,	0.4467527865,	0.5272024119, 0.3950287201,	0.3886228098,	0.4149347946,	0.4167334836]
y_DIoU_a_Car2 = [0.1249111934,	0.1268294729,	0.3167151337,	0.1131661546,	0.2468558007, 0.3689497758,	0.4859899022,	0.4933576118,	0.4874235099,	0.4540646537]
y_CIoU_a_Car2 = [0.01382094334,	0.3549516927,	0.1431296003,	0.4909731999,	0.07131122499]

plt.figure()
plt.plot(x_L1, y_L1_a_Car2, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Car2, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Car2, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Car2, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Car2, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Car2, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Car2')


y_L1_a_Basketball = [0.01148810676,	0.01260068599,	0.0228270907,	0.03227847356,	0.01906740232,	0.01790988375,	0.1674686187,	0.03683590011]
y_SmoothL1_a_Basketball = [0.02975153436,	0.03079763475,	0.03321842618,	0.02178696129,	0.02557027016,	0.1804313395,	0.02721700385,	0.06211452833]
y_IoU_a_Basketball = [0.03878032799,	0.2353622497,	0.2135835743,	0.04989960216,	0.2308145908,	0.0528683413,	0.2205621507,	0.2222434678,	0.2222450598,	0.2222450718]
y_GIoU_a_Basketball = [0.01303296006,	0.06159848575,	0.07161831086,  0.04362469223,	0.231529382,	0.04286344202,	0.2310298395,	0.1466779507]
y_DIoU_a_Basketball = [0.01973059375,	0.07196333623,	0.2695451557,	0.05870200154,	0.2808046168, 0.01941507404,	0.2256094616,	0.2183155617,	0.2183993511,	0.2141034837]
y_CIoU_a_Basketball = [0.01526937941,	0.2462586164,	0.04789406898,	0.2444646626,	0.05326693505]

plt.figure()
plt.plot(x_L1, y_L1_a_Basketball, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Basketball, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Basketball, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Basketball, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Basketball, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Basketball, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Basketball')



y_L1_a_Bird2 = [0.2150579713,	0.2530113411,	0.05220130269,	0.1476074203,	0.1903586229,	0.16639551,	0.349758382,	0.1137328775]
y_SmoothL1_a_Bird2 = [0.1602843151,	0.1531039333,	0.2006717699,	0.2111875743,	0.142520193,	0.1352089614,	0.1899522964,	0.1109386653]
y_IoU_a_Bird2 = [0.2214696564,	0.09797760294,	0.2672381036,	0.2390653831,	0.2226828874,	0.2437818464,	0.2421832,	0.2264306332,	0.2264304574,	0.2264304681]
y_GIoU_a_Bird2 = [0.211407838,	0.2926201343,	0.236719147,	0.2901513274,	0.2208804204,	0.2406865703,	0.2412965369,	0.2231918238]
y_DIoU_a_Bird2 = [0.08144715835,	0.1680945706,	0.2171290845,	0.09549744891,	0.1421140885,	0.199811156,	0.2710000334,	0.2474699054,	0.2648992023,	0.2431238149]
y_CIoU_a_Bird2 = [0.08383785082,	0.285346271,	0.1210360507,	0.1982218333,	0.3048947271]

plt.figure()
plt.plot(x_L1, y_L1_a_Bird2, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Bird2, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Bird2, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Bird2, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Bird2, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Bird2, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Bird2')



y_L1_a_Couple = [0.1387297453,	0.3017543677,	0.2201928546,	0.3752175973,	0.1739617408,	0.1176726371,	0.5980317649,	0.5987706937]
y_SmoothL1_a_Couple = [0.3713784676,	0.1344720073,	0.1327982536,	0.1463546933,	0.170610054,	0.04439200942,	0.3057321038,	0.3586388165]
y_IoU_a_Couple = [0.2684506173,	0.3473294746,	0.3353159197,	0.2840607963,	0.3468254392,	0.3618298197,	0.3444498665,	0.3300428052,	0.3300431427,	0.3300431423]
y_GIoU_a_Couple = [0.3525310967,	0.3624700833,	0.2741262131, 0.380405123,	0.3979942436,	0.3903503116,	0.3938358376,	0.3753592153]
y_DIoU_a_Couple = [0.07989636882,	0.227588445,	0.1208569988,	0.1353763537,	0.4493718647,	0.3136728911,	0.3577442607,	0.3566826102,	0.3696677993,	0.3694017431]
y_CIoU_a_Couple = [0.1155983586,	0.2242923455,	0.1208569988,	0.2635380531,	0.238423724]

plt.figure()
plt.plot(x_L1, y_L1_a_Couple, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Couple, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Couple, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Couple, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Couple, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Couple, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Couple')


y_L1_a_Bolt = [0.009844932303,	0.002020887342,	0.06181350089,	0.01334741895,	0.02374595722,	0.01695912252,	0.07031152754,	0.01608016822]
y_SmoothL1_a_Bolt = [0.00380510238,	0.01815672726,	0.02435148644,	0.02883517631,	0.01816327918,	0.007740245228,	0.02182623273,	0.03256721054]
y_IoU_a_Bolt = [0.03132580297,	0.0451362654,	0.0451362654,	0.04450178514,	0.04450178514,	0.04450178514,	0.04450178514,	0.03683412228,	0.03648442907,	0.03650819689]
y_GIoU_a_Bolt = [0.0324759667,	0.0202975644,	0.04041108686,	0.01732720387,	0.04435414909,	0.06762121764,	0.02801089831,	0.03160845105]
y_DIoU_a_Bolt = [0.1297175917,	0.08884060153,	0.02508586865,	0.1117813172,	0.04818309485,	0.0648008654,	0.0501362726,	0.05614490705,	0.0516871536,	0.05234352194]
y_CIoU_a_Bolt = [0.01700526344,	0.08884060153,	0.02508586865,	0.04145005029,	0.03970504487]

plt.figure()
plt.plot(x_L1, y_L1_a_Bolt, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Bolt, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Bolt, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Bolt, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Bolt, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Bolt, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Bolt')

y_L1_a_Skiing = [0.07316339987,	0.07942906593,	0.05566595831,	0.1877363082,	0.04424965182,	0.1721566938,	0.1488128827,	0.1914874079]
y_SmoothL1_a_Skiing = [0.07406021163,	0.07038727719,	0.05622381429,	0.06017561922,	0.04315927467,	0.1764702747,	0.06877342453,	0.06846814338]
y_IoU_a_Skiing = [0.06260491462,	0.07200719991,	0.06556700485,	0.06257608143,	0.06884453904,	0.07575894414,	0.07576258058,	0.0757611629,	0.0757611625,	0.0757611625]
y_GIoU_a_Skiing = [0.06262171761,	0.06749787209,	0.0746142074,	0.06289364081, 	0.07259176233,	0.0738848837,	0.07309080491,	0.07309351708]
y_DIoU_a_Skiing = [0.02406684519,	0.07183075854,	0.08205500011,	0.09457643922,	0.06795035724,	0.07105379226,	0.07363073053,	0.0679023173,	0.0680262442,	0.06803540662]
y_CIoU_a_Skiing = [0.07389955313,	0.07183075854,	0.08205500011,	0.06014090852,	0.2196606104]

plt.figure()
plt.plot(x_L1, y_L1_a_Bolt, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Skiing, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Skiing, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Skiing, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Skiing, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Skiing, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Skiing')




y_L1_a_Girl = [0.2055669679,	0.41898105,	0.45610362,	0.5118242111,	0.1900818941,	0.6502435361,	0.6081383461,	0.6239753828]
y_SmoothL1_a_Girl = [0.302029818,	0.1926530486,	0.2028191106,	0.1018017354,	0.1921529886,	0.5578397094,	0.5194508916,	0.5662937756]
y_IoU_a_Girl= [0.1009386775,	0.3980290428,	0.5162156973,	0.5159719493,	0.5034985187,	0.4827277197,	0.4990571887,	0.5039030632,	0.5039000294,	0.503900012]
y_GIoU_a_Girl = [0.5413424413,	0.5202592997,	0.4859068273,	0.5281347185,	0.5136293377,	0.4893373923,	0.4784486191,	0.495067925]
y_DIoU_a_Girl = [0.06998086391,	0.3460591608,	0.2523246781,	0.1117444878,	0.3176613928,	0.3487260241,	0.5119443666,	0.467241616,	0.4776298769,	0.4901273799]
y_CIoU_a_Girl = [0.03844367111,	0.3113839373,	0.2523246781,	0.595082287,	0.4251932594]

plt.figure()
plt.plot(x_L1, y_L1_a_Girl, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_Girl, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU, y_IoU_a_Girl, marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_Girl, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_Girl, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_Girl, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Girl')

y_L1_a_ave = np.mean((y_L1_a_Boy, y_L1_a_Car2, y_L1_a_Basketball, y_L1_a_Bird2, y_L1_a_Couple, y_L1_a_Bolt, y_L1_a_Skiing, y_L1_a_Girl), axis=0)
y_SmoothL1_a_ave = np.mean((y_SmoothL1_a_Boy, y_SmoothL1_a_Car2, y_SmoothL1_a_Basketball, y_SmoothL1_a_Bird2, y_SmoothL1_a_Couple, y_SmoothL1_a_Bolt, y_SmoothL1_a_Skiing, y_SmoothL1_a_Girl), axis=0)
y_IoU_a_ave= np.mean((y_IoU_a_Boy, y_IoU_a_Car2, y_IoU_a_Basketball, y_IoU_a_Bird2, y_IoU_a_Couple, y_IoU_a_Bolt, y_IoU_a_Skiing, y_IoU_a_Girl), axis=0)
y_GIoU_a_ave = np.mean((y_GIoU_a_Boy, y_GIoU_a_Car2, y_GIoU_a_Basketball, y_GIoU_a_Bird2, y_GIoU_a_Couple, y_GIoU_a_Bolt, y_GIoU_a_Skiing, y_GIoU_a_Girl), axis=0)
y_DIoU_a_ave = np.mean((y_DIoU_a_Boy, y_DIoU_a_Car2, y_DIoU_a_Basketball, y_DIoU_a_Bird2, y_DIoU_a_Couple, y_DIoU_a_Bolt, y_DIoU_a_Skiing, y_DIoU_a_Girl), axis=0)
y_CIoU_a_ave = np.mean((y_CIoU_a_Boy, y_CIoU_a_Car2, y_CIoU_a_Basketball, y_CIoU_a_Bird2, y_CIoU_a_Couple, y_CIoU_a_Bolt, y_CIoU_a_Skiing, y_CIoU_a_Girl), axis=0)

plt.figure()
plt.plot(x_L1, y_L1_a_ave, marker="o", label="L1 loss")
plt.plot(x_SmoothL1, y_SmoothL1_a_ave, marker="+", label="SmoothL1 loss")
plt.plot(x_IoU[:7], y_IoU_a_ave[:7], marker="<", label="IoU loss")
plt.plot(x_GIoU, y_GIoU_a_ave, marker="d", label="GIoU loss")
plt.plot(x_DIoU, y_DIoU_a_ave, marker="x", label="DIoU loss")
plt.plot(x_CIoU, y_CIoU_a_ave, marker="*", label="CIoU loss")
plt.xticks
plt.xlabel('iterations')
plt.ylabel('IoU')
plt.legend(loc='upper left', bbox_to_anchor=(0.65, 0.45))
plt.title('dataset: Average all data sets')

plt.show()
