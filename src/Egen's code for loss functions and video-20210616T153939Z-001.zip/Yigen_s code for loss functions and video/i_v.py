# Author: Yigen 
# This file is used to convert images to a video, which is needed to revise the size of images and the path depended on images

import cv2
import os
 
fourcc = cv2.VideoWriter_fourcc('m','p','4','v')        
# fourcc = cv2.VideoWriter_fourcc('I','4','2','0')     

cap_fps = 8
size = (576, 432)   
    

#video = cv2.VideoWriter('results/result.avi',fourcc, cap_fps, size, isColor=0)
video = cv2.VideoWriter('result.mp4',fourcc, cap_fps, size)
 

path = './result/'
file_lst = os.listdir(path)
for filename in range(1, len(file_lst)):
		img = cv2.imread(path + str(filename)+'.jpg')
		video.write(img)
video.release()


